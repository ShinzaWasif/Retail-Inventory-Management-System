-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: retail_management_system
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bills`
--

DROP TABLE IF EXISTS `bills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bills` (
  `Bill_id` int NOT NULL AUTO_INCREMENT,
  `Bill_type` varchar(50) DEFAULT NULL,
  `Bill_month` varchar(50) NOT NULL,
  `Bill_amount` decimal(10,2) NOT NULL,
  `Payment_status` varchar(20) NOT NULL,
  `store_id` int NOT NULL,
  PRIMARY KEY (`Bill_id`),
  UNIQUE KEY `Bill_id_UNIQUE` (`Bill_id`),
  KEY `fk_store_bills_id` (`store_id`),
  CONSTRAINT `fk_store_bills_id` FOREIGN KEY (`store_id`) REFERENCES `store_details` (`Store_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bills`
--

LOCK TABLES `bills` WRITE;
/*!40000 ALTER TABLE `bills` DISABLE KEYS */;
INSERT INTO `bills` VALUES (1,'Utility','September',100.00,'paid',10),(2,'Rent','December',500.00,'paid',20),(3,'Internet','June',150.00,'unpaid',8),(4,'Phone','May',200.00,'paid',17),(5,'Water','September',250.00,'paid',4),(6,'Gas','April',300.00,'unpaid',8),(7,'Electricity','May',180.00,'unpaid',9),(8,'Insurance','November',400.00,'paid',18),(9,'Trash','February',120.00,'unpaid',5),(10,'Internet','April',150.00,'paid',8),(11,'Maintenance','November',300.00,'unpaid',3),(12,'Rent','September',500.00,'unpaid',14),(13,'Security','September',250.00,'unpaid',17),(14,'Water','August',280.00,'unpaid',5),(15,'Gas','September',320.00,'unpaid',12),(16,'Internet','December',150.00,'unpaid',3),(17,'Phone','May',200.00,'unpaid',1),(18,'Rent','April',500.00,'paid',14),(19,'Utility','March',120.00,'paid',6),(20,'Insurance','February',400.00,'paid',7);
/*!40000 ALTER TABLE `bills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category` (
  `Category_id` int NOT NULL,
  `Category_name` varchar(100) NOT NULL,
  `Description` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`Category_id`),
  UNIQUE KEY `Category_id_UNIQUE` (`Category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'Electronics','Electronic gadgets'),(2,'Furniture','Home and office items'),(3,'Apparel','Clothing and fashion'),(4,'Home Decor','Furniture and decor'),(5,'Kitchenware','Kitchen tools and accessories'),(6,'Sports Equipment','Sports gear and accessories'),(7,'Books','Books and reading materials'),(8,'Toys','Children\'s toys and games'),(9,'Automotive','Vehicle parts and accessories'),(10,'Health & Beauty','Cosmetics and personal care products'),(11,'Jewelry','Fashion accessories and ornaments'),(12,'Pet Supplies','Products for pets and animals'),(13,'Garden & Outdoor','Outdoor furniture and gardening tools'),(14,'Music Instruments','Musical instruments and accessories'),(15,'Office Supplies','Stationery and office equipment'),(16,'Art & Craft','Art supplies and crafting materials'),(17,'Fitness','Fitness equipment and accessories'),(18,'Baby Products','Items for infants and toddlers'),(19,'Travel Accessories','Accessories for travel and vacations'),(20,'Food & Beverages','Food items and beverages'),(21,'Electronics','This category includes electronic devices.');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `Customer_id` int NOT NULL,
  `Customer_name` varchar(100) NOT NULL,
  `Phone_No` varchar(20) DEFAULT NULL,
  `Account_No` varchar(50) NOT NULL,
  PRIMARY KEY (`Customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'John Doe','123-4567','ACC123'),(2,'Jane Smith','987-6543','ACC456'),(3,'Alice Brown','123-7890','ACC789'),(4,'Bob Johnson','456-1230','ACC321'),(5,'Carol White','789-1234','ACC654'),(6,'Dave Green','123-4568','ACC987'),(7,'Eve Black','321-6547','ACC012'),(8,'Frank Blue','654-9870','ACC345'),(9,'Grace Gray','987-0123','ACC678'),(10,'Hank Orange','012-3456','ACC901'),(11,'Ivy Red','234-5678','ACC234'),(12,'Jack Purple','567-8901','ACC567'),(13,'Kara Yellow','890-1234','ACC890'),(14,'Leo Pink','345-6789','ACC1234'),(15,'Mia Lime','678-9012','ACC5678'),(16,'Nina Cyan','901-2345','ACC8901'),(17,'Oscar Magenta','234-5678','ACC2345'),(18,'Paul Indigo','345-6789','ACC6789'),(19,'Quinn Violet','456-7890','ACC12345'),(20,'Rachel Silver','567-8901','ACC67890');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employees` (
  `Employee_id` int NOT NULL,
  `Employee_name` varchar(100) NOT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Phone_no` varchar(20) DEFAULT NULL,
  `Role` varchar(50) NOT NULL,
  `Hire_date` date NOT NULL,
  `Salary` decimal(10,2) NOT NULL,
  `Store_id` int NOT NULL,
  PRIMARY KEY (`Employee_id`),
  UNIQUE KEY `Employee_id_UNIQUE` (`Employee_id`),
  KEY `fk_store_id` (`Store_id`),
  CONSTRAINT `fk_store_id` FOREIGN KEY (`Store_id`) REFERENCES `store_details` (`Store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES (1,'John ','john@store.com','555-3333','salesman','2023-01-01',5000.00,1),(2,'Jane','jane@store.com','555-4444','salesman','2023-02-01',5500.00,1),(3,'Alice ','alice@store.com','555-5555','salesman','2023-03-01',6000.00,1),(4,'Bob ','bob@store.com','555-6666','manager','2023-04-01',7000.00,2),(5,'Carol ','carol@store.com','555-7777','salesman','2023-05-01',8000.00,2),(6,'Dave ','dave@store.com','555-8888','manager','2023-06-01',9000.00,2),(7,'Emma ','emma@store.com','555-9999','manager','2023-07-01',6000.00,3),(8,'Frank ','frank@store.com','555-1111','manager','2023-08-01',6500.00,3),(9,'Grace ','grace@store.com','555-2222','manager','2023-09-01',7000.00,3),(10,'Henry','henry@store.com','555-3333','salesman','2023-10-01',7500.00,4),(11,'Irene ','irene@store.com','555-4444','manager','2023-11-01',8000.00,4),(12,'Jason ','jason@store.com','555-5555','manager','2023-12-01',8500.00,4),(13,'Kate ','kate@store.com','555-6666','manager','2024-01-01',9000.00,5),(14,'Leo','leo@store.com','555-7777','salesman','2024-02-01',9500.00,5),(15,'Megan ','megan@store.com','555-8888','manager','2024-03-01',10000.00,5),(16,'Nick ','nick@store.com','555-9999','manager','2024-04-01',10500.00,6),(17,'Olivia ','olivia@store.com','555-1111','manager','2024-05-01',11000.00,6),(18,'Peter ','peter@store.com','555-2222','manager','2024-06-01',11500.00,6),(19,'Quinn ','quinn@store.com','555-3333','salesman','2024-07-01',12000.00,7),(20,'Rachel ','rachel@store.com','555-4444','manager','2024-08-01',12500.00,7);
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `feedback` (
  `Feedback_id` int NOT NULL AUTO_INCREMENT,
  `Customer_id` int NOT NULL,
  `Product_id` int NOT NULL,
  `Feedback_date` date NOT NULL,
  `Rating` int NOT NULL,
  `Feedback_message` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`Feedback_id`),
  UNIQUE KEY `Feedback_id_UNIQUE` (`Feedback_id`),
  KEY `fk_customer_feedback_id` (`Customer_id`),
  KEY `fk_product_id` (`Product_id`),
  CONSTRAINT `fk_customer_feedback_id` FOREIGN KEY (`Customer_id`) REFERENCES `customers` (`Customer_id`),
  CONSTRAINT `fk_product_id` FOREIGN KEY (`Product_id`) REFERENCES `products` (`Product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedback`
--

LOCK TABLES `feedback` WRITE;
/*!40000 ALTER TABLE `feedback` DISABLE KEYS */;
INSERT INTO `feedback` VALUES (25,1,1,'2024-01-05',5,'Excellent service!'),(26,2,1,'2024-02-10',3,'Average experience'),(27,3,1,'2024-03-10',4,'Good service'),(28,4,4,'2024-04-10',2,'Poor service'),(29,5,5,'2024-05-10',5,'Excellent product'),(30,6,7,'2024-06-10',4,'Good quality'),(31,7,1,'2024-07-01',4,'Satisfied with the service'),(32,8,2,'2024-07-02',3,'Average experience'),(33,9,1,'2024-07-03',5,'Excellent service!'),(34,10,4,'2024-07-04',2,'Poor service'),(35,11,5,'2024-07-05',4,'Good product'),(36,12,7,'2024-07-06',5,'Excellent product'),(37,13,1,'2024-07-07',4,'Good quality'),(38,14,2,'2024-07-08',3,'Average quality'),(39,15,3,'2024-07-09',2,'Below average service'),(40,16,1,'2024-07-10',4,'Very good experience'),(41,17,1,'2024-07-11',5,'Top notch service!'),(42,18,6,'2024-07-12',1,'Worst experience ever'),(43,19,4,'2024-07-13',3,'Okay product');
/*!40000 ALTER TABLE `feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `financial_management`
--

DROP TABLE IF EXISTS `financial_management`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `financial_management` (
  `Financial_id` int NOT NULL AUTO_INCREMENT,
  `Total_sales` decimal(12,2) DEFAULT NULL,
  `Expenses` decimal(12,2) DEFAULT NULL,
  `Profit` decimal(12,2) DEFAULT NULL,
  `Financial_month` varchar(100) NOT NULL,
  `Store_id` int NOT NULL,
  PRIMARY KEY (`Financial_id`),
  UNIQUE KEY `Financial_id_UNIQUE` (`Financial_id`),
  KEY `fk_store_finance_id` (`Store_id`),
  CONSTRAINT `fk_store_finance_id` FOREIGN KEY (`Store_id`) REFERENCES `store_details` (`Store_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `financial_management`
--

LOCK TABLES `financial_management` WRITE;
/*!40000 ALTER TABLE `financial_management` DISABLE KEYS */;
INSERT INTO `financial_management` VALUES (1,10000.00,8000.00,2000.00,'2024-01-31',1),(2,15000.00,12000.00,3000.00,'2024-02-28',1),(3,20000.00,15000.00,5000.00,'2024-03-31',1),(4,25000.00,18000.00,7000.00,'2024-04-30',2),(5,30000.00,20000.00,10000.00,'2024-05-31',2),(6,35000.00,25000.00,10000.00,'2024-06-30',2),(7,40000.00,30000.00,10000.00,'2024-07-31',3),(8,45000.00,35000.00,10000.00,'2024-08-31',3),(9,50000.00,40000.00,10000.00,'2024-09-30',3),(10,55000.00,42000.00,13000.00,'2024-10-31',4),(11,60000.00,45000.00,15000.00,'2024-11-30',4),(12,65000.00,50000.00,15000.00,'2024-12-31',4),(13,70000.00,55000.00,15000.00,'2025-01-31',5),(14,75000.00,60000.00,15000.00,'2025-02-28',5),(15,80000.00,65000.00,15000.00,'2025-03-31',5),(16,85000.00,70000.00,15000.00,'2025-04-30',6),(17,90000.00,75000.00,15000.00,'2025-05-31',6),(18,95000.00,80000.00,15000.00,'2025-06-30',6),(19,100000.00,85000.00,15000.00,'2025-07-31',7),(20,105000.00,90000.00,15000.00,'2025-08-31',7),(24,4000.00,500.00,3500.00,'2024-06-01',2);
/*!40000 ALTER TABLE `financial_management` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory`
--

DROP TABLE IF EXISTS `inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory` (
  `Inventory_id` int NOT NULL,
  `Date_added` date NOT NULL,
  `Store_id` int NOT NULL,
  PRIMARY KEY (`Inventory_id`),
  UNIQUE KEY `Inventory_id_UNIQUE` (`Inventory_id`),
  KEY `fk_store_inv_id` (`Store_id`),
  CONSTRAINT `fk_store_inv_id` FOREIGN KEY (`Store_id`) REFERENCES `store_details` (`Store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory`
--

LOCK TABLES `inventory` WRITE;
/*!40000 ALTER TABLE `inventory` DISABLE KEYS */;
INSERT INTO `inventory` VALUES (1,'2024-01-01',3),(2,'2024-02-01',6),(3,'2024-03-01',2),(4,'2024-04-01',9),(5,'2024-05-01',1),(6,'2024-06-01',17),(7,'2024-07-01',20),(8,'2024-08-01',11),(9,'2024-09-01',13),(10,'2024-10-01',11),(11,'2024-11-01',15),(12,'2024-12-01',2),(13,'2025-01-01',6),(14,'2025-02-01',2),(15,'2025-03-01',11),(16,'2025-04-01',7),(17,'2025-05-01',4),(18,'2025-06-01',16),(19,'2025-07-01',10),(20,'2025-08-01',20),(21,'2024-02-01',3);
/*!40000 ALTER TABLE `inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_items` (
  `Order_item_id` int NOT NULL,
  `Product_id` int NOT NULL,
  `Order_id` int NOT NULL,
  `Quantity` int NOT NULL,
  `Total_price` decimal(10,2) NOT NULL,
  PRIMARY KEY (`Order_item_id`),
  KEY `fk_order_itm_id` (`Order_id`),
  KEY `fk_product_itm_id` (`Product_id`),
  CONSTRAINT `order_items_chk_1` CHECK ((`Quantity` > 0)),
  CONSTRAINT `order_items_chk_2` CHECK ((`Total_price` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_items`
--

LOCK TABLES `order_items` WRITE;
/*!40000 ALTER TABLE `order_items` DISABLE KEYS */;
INSERT INTO `order_items` VALUES (21,101,1001,5,250.00),(41,1,1001,2,19.98),(42,2,1002,1,9.99),(43,3,1003,3,29.97),(44,4,1004,1,9.99),(45,5,1005,5,49.95),(46,6,1006,2,19.98),(47,7,1007,4,39.96),(48,8,1008,1,9.99),(49,9,1009,2,19.98),(50,10,1010,1,9.99),(51,11,1011,6,59.94),(52,12,1012,1,9.99),(53,13,1013,3,29.97),(54,14,1014,2,19.98),(55,15,1015,4,39.96),(56,16,1016,1,9.99),(57,17,1017,3,29.97),(58,18,1018,2,19.98),(59,19,1019,1,9.99),(60,20,1020,5,49.95);
/*!40000 ALTER TABLE `order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `Order_id` int NOT NULL,
  `Customer_id` int NOT NULL,
  `Total_amount` decimal(10,2) DEFAULT NULL,
  `Order_date` date DEFAULT NULL,
  PRIMARY KEY (`Order_id`),
  UNIQUE KEY `Order_id_UNIQUE` (`Order_id`),
  KEY `fk_customer_order_id` (`Customer_id`),
  CONSTRAINT `fk_customer_order_id` FOREIGN KEY (`Customer_id`) REFERENCES `customers` (`Customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (1,1,50.00,'2024-01-10'),(2,2,75.00,'2024-02-15'),(3,3,150.00,'2024-03-10'),(4,4,200.00,'2024-04-15'),(5,5,250.00,'2024-05-10'),(6,6,300.00,'2024-06-15'),(7,7,100.00,'2024-07-20'),(8,8,120.00,'2024-08-25'),(9,9,180.00,'2024-09-30'),(10,10,60.00,'2024-10-05'),(11,1,220.00,'2024-11-10'),(12,2,180.00,'2024-12-15'),(13,3,100.00,'2025-01-20'),(14,4,300.00,'2025-02-25'),(15,5,90.00,'2025-03-30'),(16,6,210.00,'2025-04-05'),(17,7,160.00,'2025-05-10'),(18,8,350.00,'2025-06-15'),(19,9,180.00,'2025-07-20'),(20,10,270.00,'2025-08-25');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `Product_id` int NOT NULL,
  `Product_name` varchar(255) DEFAULT NULL,
  `Quantity` int NOT NULL,
  `Price_per_product` decimal(10,2) NOT NULL,
  `Inventory_id` int NOT NULL,
  `Category_id` int NOT NULL,
  PRIMARY KEY (`Product_id`),
  UNIQUE KEY `Product_id_UNIQUE` (`Product_id`),
  KEY `fk_category_id` (`Category_id`),
  KEY `fk_inventory_id` (`Inventory_id`),
  CONSTRAINT `fk_category_id` FOREIGN KEY (`Category_id`) REFERENCES `category` (`Category_id`),
  CONSTRAINT `fk_inventory_id` FOREIGN KEY (`Inventory_id`) REFERENCES `inventory` (`Inventory_id`),
  CONSTRAINT `products_chk_1` CHECK ((`Quantity` >= 0)),
  CONSTRAINT `products_chk_2` CHECK ((`Price_per_product` >= 0.0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'Updated Widget',120,4500.00,2,1),(2,'Updated Gizmo',75,90.00,3,2),(3,'Updated Gadget',220,3800.00,1,4),(4,'Updated Device',100,150.00,4,4),(5,'Updated Tool',150,500.00,3,3),(6,'Updated Appliance',180,250.00,2,2),(7,'Updated Product G',80,200.00,2,3),(8,'Updated Product H',150,300.00,3,4),(9,'Updated Product I',100,150.00,1,2),(10,'Updated Product J',120,250.00,2,3),(11,'Updated Product K',90,180.00,1,1),(12,'Updated Product L',200,400.00,3,4),(13,'Updated Product M',60,120.00,2,2),(14,'Updated Product N',110,220.00,1,3),(15,'Updated Product O',130,260.00,3,4),(16,'Updated Product P',70,140.00,2,2),(17,'Updated Product Q',180,360.00,1,4),(18,'Updated Product R',95,190.00,3,1),(19,'Updated Product S',85,170.00,2,2),(20,'Updated Product T',140,280.00,1,3);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchases`
--

DROP TABLE IF EXISTS `purchases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchases` (
  `Purchase_id` int NOT NULL,
  `Purchase_item` varchar(100) NOT NULL,
  `Purchase_quantity` int NOT NULL,
  `price_per_quantity` decimal(10,2) NOT NULL,
  `Purchase_date` date DEFAULT NULL,
  `Payment_status` varchar(20) NOT NULL,
  `supplier_id` int NOT NULL,
  `Store_id` int NOT NULL,
  PRIMARY KEY (`Purchase_id`),
  UNIQUE KEY `Purchase_id_UNIQUE` (`Purchase_id`),
  KEY `fk_store_purchase_id` (`Store_id`),
  KEY `fk_supplier_pur_id` (`supplier_id`),
  CONSTRAINT `fk_store_purchase_id` FOREIGN KEY (`Store_id`) REFERENCES `store_details` (`Store_id`),
  CONSTRAINT `fk_supplier_pur_id` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`Supplier_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchases`
--

LOCK TABLES `purchases` WRITE;
/*!40000 ALTER TABLE `purchases` DISABLE KEYS */;
INSERT INTO `purchases` VALUES (1,'Widget',50,10.50,'2024-01-05','Paid',1,1),(2,'Gizmo',30,15.75,'2024-02-05','Unpaid',2,2),(3,'Gadget',100,8.99,'2024-03-05','Paid',3,3),(4,'Device',75,11.25,'2024-04-05','Unpaid',1,4),(5,'Tool',150,14.50,'2024-05-05','Paid',2,5),(6,'Appliance',200,9.25,'2024-06-05','Unpaid',3,6),(7,'Furniture',80,12.75,'2024-07-05','Paid',1,7),(8,'Electronics',25,13.00,'2024-08-05','Unpaid',2,8),(9,'Home Decor',60,7.85,'2024-09-05','Paid',3,9),(10,'Kitchenware',120,10.75,'2024-10-05','Unpaid',1,10),(11,'Widget',70,16.25,'2024-11-05','Paid',2,1),(12,'Gizmo',40,8.50,'2024-12-05','Unpaid',3,2),(13,'Gadget',90,9.99,'2025-01-05','Paid',1,3),(14,'Device',55,12.50,'2025-02-05','Unpaid',2,4),(15,'Tool',180,14.75,'2025-03-05','Paid',3,5),(16,'Appliance',220,10.25,'2025-04-05','Unpaid',1,6),(17,'Furniture',100,15.50,'2025-05-05','Paid',2,7),(18,'Electronics',35,8.75,'2025-06-05','Unpaid',3,8),(19,'Home Decor',75,11.99,'2025-07-05','Paid',1,9),(20,'Kitchenware',140,13.25,'2025-08-05','Unpaid',2,10),(22,'Product A',10,50.00,'2024-07-01','Paid',1,1);
/*!40000 ALTER TABLE `purchases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `receivables`
--

DROP TABLE IF EXISTS `receivables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `receivables` (
  `Receivable_id` int NOT NULL,
  `Invoice_date` date NOT NULL,
  `Due_date` date DEFAULT NULL,
  `Amount` decimal(10,2) NOT NULL,
  `Payment_status` varchar(20) DEFAULT NULL,
  `Order_id` int NOT NULL,
  PRIMARY KEY (`Receivable_id`),
  KEY `fk_order_id_idx` (`Order_id`),
  CONSTRAINT `fk_order_id` FOREIGN KEY (`Order_id`) REFERENCES `orders` (`Order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receivables`
--

LOCK TABLES `receivables` WRITE;
/*!40000 ALTER TABLE `receivables` DISABLE KEYS */;
INSERT INTO `receivables` VALUES (1,'2024-01-01','2024-01-15',150.00,'Paid',1),(2,'2024-02-01','2024-02-15',200.00,'Unpaid',3),(3,'2024-03-01','2024-03-15',250.00,'Paid',2),(4,'2024-04-01','2024-04-15',300.00,'Unpaid',3),(5,'2024-05-01','2024-05-15',350.00,'Paid',3),(6,'2024-06-01','2024-06-15',400.00,'Unpaid',5),(7,'2024-07-01','2024-07-15',180.00,'Unpaid',5),(8,'2024-08-01','2024-08-15',220.00,'Paid',2),(9,'2024-09-01','2024-09-15',270.00,'Unpaid',1),(10,'2024-10-01','2024-10-15',320.00,'Paid',6),(11,'2024-11-01','2024-11-15',370.00,'Unpaid',7),(12,'2024-12-01','2024-12-15',420.00,'Paid',7),(13,'2025-01-01','2025-01-15',190.00,'Paid',8),(14,'2025-02-01','2025-02-15',230.00,'Unpaid',12),(15,'2025-03-01','2025-03-15',280.00,'Paid',12),(16,'2025-04-01','2025-04-15',330.00,'Unpaid',13),(17,'2025-05-01','2025-05-15',380.00,'Paid',14),(18,'2025-06-01','2025-06-15',430.00,'Unpaid',16),(19,'2025-07-01','2025-07-15',200.00,'Paid',16),(20,'2025-08-01','2025-08-15',240.00,'Unpaid',19);
/*!40000 ALTER TABLE `receivables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales`
--

DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales` (
  `Sale_id` int NOT NULL,
  `Sale_date` date NOT NULL,
  `Sale_total` decimal(10,2) NOT NULL,
  `Store_id` int NOT NULL,
  PRIMARY KEY (`Sale_id`),
  UNIQUE KEY `Sale_id_UNIQUE` (`Sale_id`),
  KEY `fk_store_sales_id` (`Store_id`),
  CONSTRAINT `fk_store_sales_id` FOREIGN KEY (`Store_id`) REFERENCES `store_details` (`Store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales`
--

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
INSERT INTO `sales` VALUES (1,'2024-01-15',1500.00,1),(2,'2024-02-20',2000.00,2),(3,'2024-03-15',2500.00,3),(4,'2024-04-20',3000.00,4),(5,'2024-05-15',3500.00,5),(6,'2024-06-20',4000.00,6),(7,'2024-07-15',4500.00,7),(8,'2024-08-20',5000.00,8),(9,'2024-09-15',5500.00,9),(10,'2024-10-20',6000.00,10),(11,'2024-11-15',6500.00,1),(12,'2024-12-20',7000.00,2),(13,'2025-01-15',7500.00,3),(14,'2025-02-20',8000.00,4),(15,'2025-03-15',8500.00,5),(16,'2025-04-20',9000.00,6),(17,'2025-05-15',9500.00,7),(18,'2025-06-20',10000.00,8),(19,'2025-07-15',10500.00,9),(20,'2025-08-20',11000.00,10),(21,'2024-07-01',500.00,1);
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `store_details`
--

DROP TABLE IF EXISTS `store_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `store_details` (
  `Store_id` int NOT NULL,
  `Store_name` varchar(255) NOT NULL,
  `Address` varchar(255) NOT NULL,
  `Postal_code` varchar(10) NOT NULL,
  `Phone_no` varchar(20) DEFAULT NULL,
  `Opening_hours` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Store_id`),
  UNIQUE KEY `Store_id_UNIQUE` (`Store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `store_details`
--

LOCK TABLES `store_details` WRITE;
/*!40000 ALTER TABLE `store_details` DISABLE KEYS */;
INSERT INTO `store_details` VALUES (1,'Store A','123 Main St','12345','555-1111','9am-9pm'),(2,'Store D','987 Birch St','76543','555-6666','8am-6pm'),(3,'Store B','456 Oak St','54321','555-2222','10am-8pm'),(4,'Store C','789 Pine St','87654','555-7777','7am-5pm'),(5,'Store E','321 Elm St','98765','555-3333','11am-10pm'),(6,'Store F','654 Cedar St','23456','555-8888','8am-6pm'),(7,'Store G','876 Maple St','65432','555-4444','9am-9pm'),(8,'Store H','210 Walnut St','34567','555-9999','10am-8pm'),(9,'Store I','543 Pineapple St','45678','555-5555','7am-5pm'),(10,'Store J','678 Orange St','98765','555-1111','11am-10pm'),(11,'Store K','901 Lemon St','87654','555-6666','8am-6pm'),(12,'Store L','234 Grape St','76543','555-2222','9am-9pm'),(13,'Store M','567 Banana St','65432','555-7777','10am-8pm'),(14,'Store N','890 Mango St','54321','555-3333','7am-5pm'),(15,'Store O','123 Peach St','43210','555-8888','11am-10pm'),(16,'Store P','456 Plum St','32109','555-4444','8am-6pm'),(17,'Store Q','789 Cherry St','21098','555-9999','9am-9pm'),(18,'Store R','012 Berry St','10987','555-5555','10am-8pm'),(19,'Store S','345 Avocado St','87654','555-1111','7am-5pm'),(20,'Store T','678 Tomato St','76543','555-6666','11am-10pm'),(22,'Store A','123 Main St','12345','555-1234','9 AM - 5 PM');
/*!40000 ALTER TABLE `store_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier_payables`
--

DROP TABLE IF EXISTS `supplier_payables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supplier_payables` (
  `Payable_id` int NOT NULL,
  `Invoice_date` date NOT NULL,
  `Due_date` date DEFAULT NULL,
  `Payable_amount` decimal(10,2) NOT NULL,
  `Payment_status` varchar(20) NOT NULL,
  `Supplier_id` int NOT NULL,
  PRIMARY KEY (`Payable_id`),
  UNIQUE KEY `Payable_id_UNIQUE` (`Payable_id`),
  KEY `fk_supplier_id` (`Supplier_id`),
  CONSTRAINT `fk_supplier_id` FOREIGN KEY (`Supplier_id`) REFERENCES `suppliers` (`Supplier_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier_payables`
--

LOCK TABLES `supplier_payables` WRITE;
/*!40000 ALTER TABLE `supplier_payables` DISABLE KEYS */;
INSERT INTO `supplier_payables` VALUES (1,'2024-01-01','2024-01-15',250.00,'Paid',1),(2,'2024-02-01','2024-02-15',300.00,'Unpaid',2),(3,'2024-03-01','2024-03-15',350.00,'Paid',3),(4,'2024-04-01','2024-04-15',400.00,'Unpaid',4),(5,'2024-05-01','2024-05-15',450.00,'Paid',5),(6,'2024-06-01','2024-06-15',500.00,'Unpaid',6),(7,'2024-07-01','2024-07-15',270.00,'Unpaid',7),(8,'2024-08-01','2024-08-15',320.00,'Paid',8),(9,'2024-09-01','2024-09-15',370.00,'Unpaid',9),(10,'2024-10-01','2024-10-15',420.00,'Paid',10),(11,'2024-11-01','2024-11-15',470.00,'Unpaid',11),(12,'2024-12-01','2024-12-15',520.00,'Paid',12),(13,'2025-01-01','2025-01-15',280.00,'Paid',13),(14,'2025-02-01','2025-02-15',330.00,'Unpaid',14),(15,'2025-03-01','2025-03-15',380.00,'Paid',15),(16,'2025-04-01','2025-04-15',430.00,'Unpaid',16),(17,'2025-05-01','2025-05-15',480.00,'Paid',17),(18,'2025-06-01','2025-06-15',530.00,'Unpaid',18),(19,'2025-07-01','2025-07-15',290.00,'Paid',19),(20,'2025-08-01','2025-08-15',340.00,'Unpaid',20);
/*!40000 ALTER TABLE `supplier_payables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `suppliers` (
  `Supplier_id` int NOT NULL,
  `Supplier_name` varchar(100) NOT NULL,
  `Phone_no` varchar(15) NOT NULL,
  `Contact_person` varchar(100) DEFAULT NULL,
  `City` varchar(50) NOT NULL,
  PRIMARY KEY (`Supplier_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suppliers`
--

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
INSERT INTO `suppliers` VALUES (1,'ABC Supplies','555-1234','Alice Johnson','New York'),(2,'XYZ Traders','555-5678','Bob Brown','Los Angeles'),(3,'LMN Goods','555-6789','Carol Smith','Chicago'),(4,'OPQ Supplies','555-7890','Dave Clark','Miami'),(5,'RST Traders','555-8901','Eve Martin','Dallas'),(6,'UVW Goods','555-9012','Frank White','Houston'),(7,'GHI Supplies','555-2345','George Davis','Seattle'),(8,'JKL Traders','555-3456','Hannah Lee','San Francisco'),(9,'MNO Goods','555-4567','Ian Wilson','Boston'),(10,'PQR Supplies','555-5678','Jackie Young','Phoenix'),(11,'STU Traders','555-6789','Kate Adams','Denver'),(12,'VWX Goods','555-7890','Liam Roberts','Atlanta'),(13,'DEF Supplies','555-8901','Maria Rodriguez','Detroit'),(14,'NOP Traders','555-9012','Nathan Harris','Portland'),(15,'QRS Goods','555-1234','Olivia Allen','San Diego'),(16,'TUV Supplies','555-2345','Peter Thompson','Austin'),(17,'XYZ Traders','555-3456','Quincy Turner','Las Vegas'),(18,'UVW Goods','555-4567','Rachel Scott','Philadelphia'),(19,'LMN Supplies','555-5678','Samuel Green','Charlotte'),(20,'OPQ Traders','555-6789','Tina Martinez','Washington D.C.');
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'retail_management_system'
--

--
-- Dumping routines for database 'retail_management_system'
--
/*!50003 DROP PROCEDURE IF EXISTS `addFinancialManagement` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `addFinancialManagement`(
    IN Store_id INT,
    IN Financial_month DATE
)
BEGIN
    DECLARE Total_sales DECIMAL(10,2) DEFAULT 0;
    DECLARE Expenses DECIMAL(10,2) DEFAULT 0;
    
    -- Calculate Total Sales for the given Store_id and Financial_month
    SELECT IFNULL(SUM(Sale_total), 0)
    INTO Total_sales
    FROM sales
    WHERE Store_id = Store_id
      AND DATE_FORMAT(Sale_date, '%Y-%m') = DATE_FORMAT(Financial_month, '%Y-%m');
    
    -- Calculate Total Expenses (sum of payables and bills) for the given Store_id and Financial_month 
    SELECT IFNULL(SUM(Payable_amount), 0) + IFNULL(SUM(Bill_amount), 0) 
    INTO Expenses
    FROM (
        SELECT Payable_amount, NULL AS Bill_amount
        FROM supplier_payables 
        WHERE Store_id = Store_id 
          AND DATE_FORMAT(Due_date, '%Y-%m') = DATE_FORMAT(Financial_month, '%Y-%m')
        
        UNION ALL 
        
        SELECT NULL AS Payable_amount, Bill_amount
        FROM bills 
        WHERE Store_id = Store_id 
          AND bill_month = Financial_month
          AND Payment_status = 'Paid'
    ) AS combined_expenses; 
    
    -- Insert the calculated values into financial_management table 
    INSERT INTO financial_management (Store_id, Financial_month, Total_sales, Expenses,Profit) 
    VALUES (Store_id, Financial_month, Total_sales, Expenses,Total_sales-Expenses);
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `add_bill` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_bill`(
  
    IN p_Bill_id INT,
    IN p_Bill_type VARCHAR(50),
    IN p_Bill_month VARCHAR(50),
    IN p_Bill_amount DECIMAL(10, 2),
    IN p_Payment_status VARCHAR(20),
      IN p_Store_id INT
)
BEGIN
    INSERT INTO bills (Bill_id, Bill_type, Bill_month, Bill_amount, Payment_status,Store_id )
    VALUES ( p_Bill_id, p_Bill_type, p_Bill_month, p_Bill_amount, p_Payment_status,p_Store_id);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `add_category` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_category`(
 	IN Category_id INT,
 	IN Category_name VARCHAR(100),
 	IN Description VARCHAR(500)
 )
BEGIN
 	INSERT INTO category (Category_id, Category_name, Description)
 	VALUES (Category_id, Category_name, Description);
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `add_customer` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_customer`(
   IN Customer_id INT,
    IN Customer_name VARCHAR(100),
    IN Phone_no VARCHAR(20),
    IN Account_no VARCHAR(50)
)
BEGIN
INSERT INTO Customers (Customer_id, Customer_name, Phone_no, Account_no) 
    VALUES (Customer_id, Customer_name, Phone_no, Account_no);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `add_employee` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_employee`(
IN Employee_id INT,
 	IN Employee_name VARCHAR(100),
    IN email VARCHAR(255),
	IN Phone_no VARCHAR(20),
 	IN Role VARCHAR(20),
    	IN Hire_date DATE,
 	IN Salary DECIMAL(10,2),
 
IN Store_id INT
)
BEGIN
 	INSERT INTO employees (Employee_id,Employee_name,email,Phone_no,Role,Hire_date,Salary,Store_id)
 	VALUES (Employee_id,Employee_name,email,Phone_no,Role,Hire_date,Salary,Store_id);
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `add_feedback` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_feedback`(
    IN p_Customer_id INT,
     IN p_Product_id INT,
    IN p_Feedback_date DATE,
    IN p_Rating INT,
    IN p_Feedback_message VARCHAR(500)
   
)
BEGIN
    INSERT INTO feedback (Customer_id,Product_id, Feedback_date, Rating, Feedback_message)
    VALUES (p_Customer_id,p_Product_id, p_Feedback_date, p_Rating, p_Feedback_message);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `add_inventory` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_inventory`(
 IN p_Inventory_id INT,
    IN p_Date_added DATE,
    IN p_Store_id INT
)
BEGIN
  INSERT INTO Inventory (Inventory_id, Date_added, Store_id)
    VALUES (p_Inventory_id, p_Date_added, p_Store_id);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `add_order_item` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_order_item`(
    IN p_Order_item_id INT,
    IN p_Product_id INT,
    IN p_Order_no INT,
    IN p_Quantity INT,
    IN p_Total_price DECIMAL(10, 2)
)
BEGIN
    INSERT INTO order_items (Order_item_id, Product_id, Order_id, Quantity, Total_price)
    VALUES (p_Order_item_id, p_Product_id, p_Order_no, p_Quantity, p_Total_price);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `add_product` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_product`(
    IN Product_id INT,
    IN Product_name VARCHAR(255),
    IN Inventory_id INT,
    IN Category_id INT
)
BEGIN
    DECLARE category_exists INT;

    -- Check if the provided Category_id exists in the category table
    SELECT COUNT(*) INTO category_exists FROM category WHERE Category_id = Category_id;

    IF category_exists = 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Error: Invalid Category_id. Category_id does not exist.';
    ELSE
        -- Insert the product into the products table
INSERT INTO products (Product_id,Product_name, Price_per_product, Quantity) 
SELECT Purchase_item, Price_per_quantity, Purchase_quantity
 FROM purchases
 WHERE purchase_item = Product_name;       
INSERT INTO products (Inventory_id, Category_id)
        VALUES (Inventory_id, Category_id);
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `add_purchase` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_purchase`(
    IN p_Purchase_id INT,
    IN p_Purchase_item VARCHAR(100),
    IN p_Purchase_quantity VARCHAR(500),
    IN p_Price_per_quantity DECIMAL(10,2),
    IN p_Purchase_date DATE,
    IN p_Payment_Status VARCHAR(20),
    IN p_Supplier_id int,
    IN p_Store_id int
    )
BEGIN
    INSERT INTO purchases (Purchase_id, Purchase_item, Purchase_quantity, Price_per_quantity, Purchase_date, Payment_Status, Supplier_id, Store_id)
    VALUES (p_Purchase_id, p_Purchase_item, p_Purchase_quantity, p_Price_per_quantity, p_Purchase_date, p_Payment_Status, p_Supplier_id, p_Store_id);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `add_sales` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_sales`(
 	IN Sale_id INT,
 	IN Store_id INT,
 	IN Sale_date Date,
 	IN Sale_total DECIMAL(10,2)
 )
BEGIN
 	INSERT INTO sales (Sale_id, Store_id, Sale_date, Sale_total)
 	VALUES (Sale_id, Store_id, Sale_date, Sale_total);
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `add_store_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_store_details`(
    IN p_Store_id INT,
    IN p_Store_name VARCHAR(100),
    IN p_Address VARCHAR(255),
    IN p_Postal_code VARCHAR(20),
    IN p_Phone_no VARCHAR(20),
    IN p_Opening_hours VARCHAR(100)
)
BEGIN
    INSERT INTO store_details (Store_id, Store_name, Address, Postal_code, Phone_no, Opening_hours)
    VALUES (p_Store_id, p_Store_name, p_Address, p_Postal_code, p_Phone_no, p_Opening_hours);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `add_supplier` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_supplier`(
	IN Supplier_id INT,
 	IN Supplier_name VARCHAR(100),
 	IN Phone_no VARCHAR(15),
 	IN Contact_Person VARCHAR(100),
	IN City VARCHAR(50)
)
BEGIN
INSERT INTO suppliers (Supplier_id, Supplier_name, Phone_no,Contact_Person,City)
 	VALUES (Supplier_id, Supplier_name, Phone_no,Contact_Person,City);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `delete_employee` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `delete_employee`(
IN Employee_id INT

)
BEGIN
 	DELETE FROM employees
 	WHERE Employee_id= Employee_id;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `delete_feedback` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `delete_feedback`(
    IN p_Feedback_ID INT
)
BEGIN
    -- Check if Feedback_id exists
    IF NOT EXISTS (SELECT 1 FROM feedback WHERE Feedback_id = p_Feedback_ID) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Feedback_id does not exist';
    END IF;
    
    -- Delete feedback record
    DELETE FROM feedback WHERE Feedback_id = p_Feedback_ID;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `delete_inventory` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `delete_inventory`(
  IN p_Inventory_id INT
)
BEGIN
   DELETE FROM inventory
    WHERE Inventory_id = p_Inventory_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `delete_supplier` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `delete_supplier`(
IN Supplier_id INT
)
BEGIN
 	DELETE FROM suppliers
 	WHERE Supplier_id= Supplier_id;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_customersDetails` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_customersDetails`()
BEGIN
SELECT * FROM customers;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_employee` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_employee`()
BEGIN
 	SELECT * FROM employees;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_feedback` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_feedback`()
BEGIN
    SELECT * FROM feedback;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_financial_mang` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_financial_mang`()
BEGIN
select * from financial_management;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_inventory` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_inventory`()
BEGIN
SELECT * FROM inventory;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_receivables` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_receivables`()
BEGIN
select * from receivables;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_sales` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_sales`()
BEGIN
select * from sales;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_supplier` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_supplier`()
BEGIN
 	SELECT * FROM suppliers;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_customer` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_customer`(
   IN Customer_id INT,
    IN Phone_no VARCHAR(50)
)
BEGIN
UPDATE customers 
    SET Phone_no = Phone_no 
    WHERE Customer_id = Customer_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_employee` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_employee`(
IN Employee_id INT,
 	IN Employee_name VARCHAR(100),
    IN email VARCHAR(255),
	IN Phone_no VARCHAR(20),
 	IN Role VARCHAR(20),
    	IN Hire_date DATE,
 	IN Salary DECIMAL(10,2),
 
IN Store_id INT
)
BEGIN
	UPDATE employees
 	SET Employee_name = Employee_name, Role = Role, Salary = Salary, Hire_date = Hire_date, Store_id = Store_id,Phone_no=Phone_no,email=email
 	WHERE Employee_id = EmployeeId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_inventory` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_inventory`(
IN p_Inventory_id INT,
    IN p_Date_added DATE,
    IN p_Store_id INT
)
BEGIN
  UPDATE inventory
    SET Date_added = p_Date_added, Store_id = p_Store_id
    WHERE Inventory_id = p_Inventory_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_supplier` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_supplier`(
    IN SupplierId INT,
 	IN SupplierName VARCHAR(100),
 	IN PhoneNo VARCHAR(15),
 	IN ContactPerson VARCHAR(100),
IN CityName VARCHAR(50)
)
BEGIN
 	UPDATE suppliers
 	SET Supplier_name = SupplierName, Phone_no =PhoneNo, Contact_Person = ContactPerson, City = CityName
 	WHERE Supplier_id = p_SupplierId;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-30 23:25:19
