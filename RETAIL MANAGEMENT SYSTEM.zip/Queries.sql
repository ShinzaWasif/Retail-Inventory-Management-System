-- use my_retail_inventory
-- SELECT
SELECT * FROM customers WHERE Customer_id = 1;	-- Single Customer Query
SELECT * FROM order_items WHERE Order_id = 1001 AND Product_id = 101;	-- Single Order Item Query
SELECT COUNT(*) AS total_customers FROM customers;	-- Total Customers Count Query
SELECT COUNT(*) AS total_order_items FROM order_items;	-- Total Order Items Count Query
SELECT CONCAT(Product_name, ' - ',Price_per_product ) AS Product_info FROM products;	-- Product Information Concatenation Query

-- WHERE
SELECT * FROM products WHERE Price_per_product > 15.00;	-- Products by Price Query
SELECT * FROM orders WHERE Order_date = '2024-10-05';	-- Orders on Specific Date Query
SELECT * FROM customers WHERE Phone_no LIKE '%123%';	-- Customers by Phone Number Query
SELECT * FROM purchases WHERE Supplier_id = 1;   -- 	Purchases by Supplier Query

-- Single Row Functions
SELECT UPPER(Customer_name) AS customer_name_upper FROM customers;	-- Customer Name Uppercase Query
SELECT Order_id, DAYNAME(Order_date) AS order_day FROM orders;	-- Order Day of Week Query
SELECT * FROM orders WHERE MONTH(Order_date) = 1; -- AND YEAR(Order_date) = 2023;	
SELECT Customer_name, LEFT(Customer_name, 3) AS name_prefix FROM customers;	-- selecting customer names along with their first three characters as a prefix

-- Joining Queries
SELECT orders.Order_id, customers.Customer_name, orders.Order_date 
FROM orders 
JOIN customers
 ON orders.Customer_id = customers.Customer_id;	

SELECT 
    products.Product_id, 
    products.Product_name,  category.Category_name,
    products.Price_per_product, 
    products.Quantity
   
FROM products
JOIN 
    category ON products.Category_id = category.Category_id
WHERE 
    products.Inventory_id =2;

SELECT 
    feedback.Feedback_id,
    feedback.Customer_id,
    feedback.Feedback_date,
    feedback.Rating,
    feedback.Feedback_message,
    feedback.Product_id,
    products.product_name, -- Assuming you want to include product details
    category.category_name -- Assuming you want to include category details if available
FROM 
    feedback
JOIN 
    products ON feedback.Product_id = products.product_id
LEFT JOIN 
    category ON products.category_id = category.category_id;


-- Subqueries
SELECT * FROM customers WHERE Customer_id IN (SELECT Customer_id FROM orders);	-- selecting customers who have placed orders.

SELECT * FROM products WHERE Price_per_product = (SELECT MAX(Total_price) FROM order_items);	-- Max Price Comparison Query

SELECT * FROM suppliers WHERE Supplier_id IN (
    SELECT Supplier_id
    FROM supplier_payables
    WHERE Payable_amount = (
        SELECT MAX(Payable_amount)
        FROM supplier_payables
    )
);

